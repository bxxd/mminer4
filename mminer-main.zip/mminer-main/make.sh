nvcc -lgmp -O3 -o mminer Keccak1600v1mpunk.cu
