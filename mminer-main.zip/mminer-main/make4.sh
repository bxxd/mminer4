nvcc -lgmp -O3 -o mminer4 Keccak1600v1.4mpunk.cu
