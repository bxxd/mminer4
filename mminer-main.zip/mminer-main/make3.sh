nvcc -lgmp -O3 -o mminer3 Keccak1600v1.3mpunk.cu
