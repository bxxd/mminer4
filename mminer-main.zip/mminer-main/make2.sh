nvcc -lgmp -lcurand -o mminer2 Keccak1600v1.2mpunk.cu
