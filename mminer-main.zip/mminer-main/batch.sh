

./mminer4 -x 0  > out01 &
sleep 1
./mminer4 -x 0  > out02 &
#./mminer4 -x 1 -s 0x0200000000000000 > out11 &
#./mminer4 -x 1 -s 0x0300000000000000 > out12 &
#./mminer4 -x 2 -s 0x0400000000000000 > out21 &
#./mminer4 -x 2 -s 0x0500000000000000 > out22 &
#./mminer4 -x 3 -s 0x0600000000000000 > out31 &
#./mminer4 -x 3 -s 0x0700000000000000 > out32 &


